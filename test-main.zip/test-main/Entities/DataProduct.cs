﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mini.Entities
{
    public class DataProduct
    {
        public IEnumerable<Product> products { get; set; }
    }
}
